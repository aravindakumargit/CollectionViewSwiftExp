//
//  MyCollectionViewCell.swift
//  CollectionViewSwiftExp
//
//  Created by Aravindakumar Arunachalam on 27/09/17.
//  Copyright © 2017 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var imgCell: UIImageView!
    
}
