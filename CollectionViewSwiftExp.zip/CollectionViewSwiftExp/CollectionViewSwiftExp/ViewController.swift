//
//  ViewController.swift
//  CollectionViewSwiftExp
//
//  Created by Aravindakumar Arunachalam on 27/09/17.
//  Copyright © 2017 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
    @IBOutlet weak var CollectionView: UICollectionView!
    var country = [String]()
    var flag = [String]()
    let reuseIdentifier = "cell"
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        hitserver()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.country.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath as IndexPath) as! MyCollectionViewCell
        
       
        cell.lbl.text = self.country[indexPath.item]
        
 //       withoutLazyLoading
//        let url = URL(string:self.flag[indexPath.item])
//        let data = try? Data(contentsOf: url!)
//        cell.imgCell.image = UIImage(data: data!)
        
        cell.imgCell.sd_setImage(with: URL(string:self.flag[indexPath.row] ) )
     
        return cell
    }
    
    // MARK: - UICollectionViewDelegate protocol
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // handle tap events
        print("You selected cell #\(indexPath.item)!")
    }
    func hitserver(){
        var dict_response = NSMutableDictionary()

        var worldpopulation = NSArray()
        var request = URLRequest(url:URL(string:"http://www.androidbegin.com/tutorial/jsonparsetutorial.txt")!)
        let session = URLSession.shared
        request.httpMethod = "GET"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        let task = session.dataTask(with: request, completionHandler: {data, response, error -> Void           in
            guard error == nil && data != nil else
            {
                print("error=\(error)")
                return
            }
            
            do
            { try
                dict_response = JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSMutableDictionary
                DispatchQueue.main.async { () -> Void in
                
               
                print(dict_response)
               worldpopulation = dict_response["worldpopulation"]as! NSArray as! NSMutableArray
               
                for index in 0...worldpopulation.count-1 {
                    let aObject = worldpopulation[index] as! [String : AnyObject]
                   self.country.append(aObject["country"] as! String)
                    self.flag.append(aObject["flag"]as! String)
                                  }
                print(self.country)
                print(self.flag)
                    self.CollectionView .reloadData()

                }
            }
            catch
            {
                print("Error Execption")
                DispatchQueue.main.async { () -> Void in
                }
            }
            
            
        })
        task.resume()
    }

    }


